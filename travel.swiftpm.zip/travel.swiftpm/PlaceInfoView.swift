// PlaceInfoView.swift

import SwiftUI

struct PlaceInfoView: View {
    let placeInfo: PlaceInfo

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text(placeInfo.name)
                    .font(.title)
                    .foregroundColor(.primary)

                Text(placeInfo.description)
                    .foregroundColor(.secondary)
                    .padding()

                // You can add more details or customize the view as needed

            }
            .padding()
            .navigationBarTitle(placeInfo.name, displayMode: .inline)
        }
    }
}

struct PlaceInfoView_Previews: PreviewProvider {
    static var previews: some View {
       
        PlaceInfoView(placeInfo:
            PlaceInfo.premMandir)
        PlaceInfoView(placeInfo:
            PlaceInfo.nidhivan)
        PlaceInfoView(placeInfo:
            PlaceInfo.krishnaJanambhumi)
       
        
    }
}
