// PlaceInfo.swift

import Foundation

struct PlaceInfo {
    let name: String
    let description: String
}
// PlaceInfo+Extensions.swift

// PlaceInfo+Extensions.swift

// PlaceInfo+Extensions.swift

import Foundation

extension PlaceInfo {

    static var premMandir: PlaceInfo {
        return PlaceInfo(
            name: "Prem Mandir",
            description: """
            Radhe Radhe!
            Prem Mandir is 7 km away from the Railway station and
            6 km away from Banke Bihari Temple.
            Darshan Timing is 8:30 AM to 12:30 pm.
            You can visit ISKON TEMPLE in between of your route.
            """
        )
    }

    static var nidhivan: PlaceInfo {
        return PlaceInfo(
            name: "Nidhivan",
            description: """
            It is 6 km away from the Railway station.
            Timings are 6:00 AM to 6:00 PM.
            Nidhivan Mystery
            Nidhivan consists of one palace that is named Rang Mahal. In the Rang Mahal, there is a bed of sandalwood which is prepared every night for Lord Krishna. They keep the jar that is filled with water beside the bed. Not only this, but they also place several other things like Neem Daatun for brushing teeth and Pan.

            It is faith that, in the morning when the doors off Rang Mahal open that bed looks as if somebody has slept on Sandalwood. Along with it, the water that is kept in Jar, Neem Datun, and Pan also looked like consumed.

            """
        )
    }

    static var krishnaJanambhumi: PlaceInfo {
        return PlaceInfo(
            name: "Krishna Janambhumi",
            description: """
            Radhe Radhe!
            It is located in Mathura, which is 10 km away from Vrindavan Railway station.
            Phones and electronic items are strictly prohibited here.
            Timings are 7:00 AM to 12:30 PM.
            Story:
            The Krishna Janmasthan, at Mathura,  is important because this is where Lord Shri Krishna manifested Himself in the prison house of the cruel king Kansa and set free his father Vasudeva and his mother Devaki. His purpose was to destroy evil, protect the virtuous, and establish righteousness on a firm footing. Adjacent to the entrance of the prison cell, stands the temple where Astabhuja Maa Yogmaya manifested. The divine ambience of the sanctum sanctorum thrills the hearts of the devotees as soon as they enter the auspicious place, and a sense of conviction surges in their minds that this indeed is the place where Lord Krishna manifested Himself. He gave mankind extraordinary and thought provoking ideas, in the Sacred Scripture, The Bhagavata Gita. The Bhagavat Gita lays the basis of how life should be led in the various walks that govern our life on this earth,  as our soul is immortal!
            """
        )
    }

   
}
