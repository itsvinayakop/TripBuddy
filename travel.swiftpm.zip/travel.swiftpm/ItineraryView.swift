// ItineraryView.swift

import SwiftUI

struct ItineraryView: View {
    let selectedPlaces: Set<String>

    let placeInfoDictionary: [String: PlaceInfo] = [
        "Prem Mandir": PlaceInfo.premMandir,
        "Nidhivan": PlaceInfo.nidhivan,
        "Krishna Janambhumi": PlaceInfo.krishnaJanambhumi,
        // Add entries for other places...
    ]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 20) {
                ForEach(selectedPlaces.sorted(), id: \.self) { place in
                    if let placeInfo = placeInfoDictionary[place] {
                        ItineraryItemView(item: ItineraryItem(name: place, photo: "defaultImage", distance: ""), placeInfo: placeInfo)
                            .frame(width: 300) // Set the desired width for each item
                            .onAppear {
                                print("PlaceInfo found for \(place)")
                            }
                    } else {
                        // Placeholder view to avoid '()' issue
                        EmptyView()
                            .onAppear {
                                print("No PlaceInfo found for \(place)")
                            }
                    }
                }
                Spacer() // Add a Spacer to push content upwards
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 20)
            
            // Notice at the bottom
            Text("Click on any image to know some interesting facts")
                .foregroundColor(.red)
                .padding(.bottom, 16)
        }
        .navigationBarTitle("Itinerary", displayMode: .inline)
        .navigationBarBackButtonHidden(true) // Hide the back button
    }
}

struct ItineraryView_Previews: PreviewProvider {
    static var previews: some View {
        ItineraryView(selectedPlaces: ["Prem Mandir", "Nidhivan", "Krishna Janambhumi"])
    }
}
