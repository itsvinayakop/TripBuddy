import SwiftUI

struct LocationView: View {
    // Access to presentation mode for dismissing the current view
    @Environment(\.presentationMode) var presentationMode
    
    // Selected city and famous places
    let city: String
    let famousPlaces: [String]
    
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                
                // Title with selected city
                Text("Trip Buddy - \(city)")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 20)
                
                // Navigation button to go to FamousPlacesView
                NavigationLink(destination: FamousPlacesView(famousPlaces: famousPlaces)) {
                    Text("View Famous Places")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                        .padding(.bottom, 20)
                }
                
                Spacer()
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .edgesIgnoringSafeArea(.all)
            .navigationBarTitle("Select Location", displayMode: .inline)
        }
    }
}
