import SwiftUI
struct ArrowView: View {
    let startPoint: String
    let endPoint: String
    let distance: String
    let travelMode: String

    var body: some View {
        VStack {
            Image(systemName: "arrow.right.circle")
                .resizable()
                .frame(width: 30, height: 30)
                .foregroundColor(.blue)

            Text("Distance: \(distance)")
                .font(.caption)
                .foregroundColor(.secondary)

            Text("Mode: \(travelMode)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

