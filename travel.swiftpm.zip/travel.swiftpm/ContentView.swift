// ContentView.swift

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .topLeading, endPoint: .bottomTrailing).edgesIgnoringSafeArea(.all)
                
                VStack {
                    Spacer()
                    
                    Image(systemName: "airplane")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 150, height: 150)
                        .foregroundColor(.black)
                    
                    Text("Trip Buddy")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.top, 20)
                    
                    Spacer()
                    
                    NavigationLink(destination: ExistingContentView()) {
                        Text("Start Your Journey")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
                            .padding(.bottom, 20)
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// ExistingContentView.swift

import SwiftUI

struct ExistingContentView: View {
    @Environment(\.presentationMode) var presentationMode
    let cities = ["Vrindavan", "Haridwar", "Mussoorie"]
    
    @State private var selectedCity = "Vrindavan"
    @State private var startDate = Date()
    @State private var endDate = Date()
    
    var body: some View {
        VStack {
            Text("Trip Buddy")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            Picker("Select City", selection: $selectedCity) {
                ForEach(cities, id: \.self) { city in
                    Text(city)
                }
            }
            .pickerStyle(MenuPickerStyle())
            .padding(.horizontal)
            .padding(.bottom, 10)
            
            HStack {
                Text("Start Date:")
                Spacer()
                DatePicker("", selection: $startDate, displayedComponents: .date)
                    .labelsHidden()
                    .datePickerStyle(GraphicalDatePickerStyle())
                    .padding(.horizontal)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
            }
            .padding(.horizontal)
            .padding(.bottom, 10)
            
            HStack {
                Text("End Date:")
                Spacer()
                DatePicker("", selection: $endDate, displayedComponents: .date)
                    .labelsHidden()
                    .datePickerStyle(GraphicalDatePickerStyle())
                    .padding(.horizontal)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
            
            NavigationLink(destination: LocationView(city: selectedCity, famousPlaces: getFamousPlaces(for: selectedCity))) {
                Text("Select Location")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(8)
                    .padding(.bottom, 20)
            }
            
            Text("Selected City: \(selectedCity)")
                .padding(.bottom, 5)
            Text("Selected Date Range: \(formattedDate(startDate)) to \(formattedDate(endDate))")
            
            Spacer()
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .edgesIgnoringSafeArea(.all)
        .navigationBarTitle("", displayMode: .inline)
    }
    
    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter.string(from: date)
    }
    
    func getFamousPlaces(for city: String) -> [String] {
        switch city {
        case "Vrindavan":
            return ["Nidhivan", "Prem Mandir",  "Krishna Janambhumi"]
            // Add cases for other cities as needed
        default:
            return []
        }
    }
}

struct ExistingContentView_Previews: PreviewProvider {
    static var previews: some View {
        ExistingContentView()
    }
}

// Additional files (LocationView, ArrowView, ItineraryItemView) remain unchanged

