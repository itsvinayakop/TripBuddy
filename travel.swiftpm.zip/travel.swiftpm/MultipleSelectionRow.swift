import SwiftUI

struct MultipleSelectionRow: View {
    var title: String
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Image(systemName: isSelected ? "checkmark" : "")
        }
        .contentShape(Rectangle())
        .onTapGesture {
            action()
        }
    }
}
