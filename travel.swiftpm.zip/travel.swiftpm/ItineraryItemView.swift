// ItineraryItemView.swift

import SwiftUI

struct ItineraryItemView: View {
    let item: ItineraryItem
    let placeInfo: PlaceInfo // Make sure you have this property

    var body: some View {
        NavigationLink(destination: PlaceInfoView(placeInfo: placeInfo)) {
            VStack(spacing: 8) {
                Image(item.name.replacingOccurrences(of: " ", with: ""))
                    .resizable()
                    .scaledToFit()
                    .frame(height: 150)
                    .cornerRadius(8)

                Text(item.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .padding(.top, 4) // Add minimal padding to place the text below the image

                if !item.distance.isEmpty {
                    Text("Distance: \(item.distance)")
                        .foregroundColor(.secondary)
                        .padding(.bottom, 4) // Add minimal padding to separate the distance from the text below
                }
            }
        }
        .padding(8) // Add padding around the entire content
        .background(Color.white)
        .cornerRadius(8)
        .shadow(radius: 3)
    }
}
