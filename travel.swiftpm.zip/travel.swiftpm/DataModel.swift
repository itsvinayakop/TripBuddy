import Foundation

struct ItineraryItem: Identifiable {
    let id = UUID()
    let name: String
    let photo: String
    let distance: String
}

let itineraryData: [ItineraryItem] = [
    ItineraryItem(name: "Railway Station", photo: "train", distance: "0 Km"),
    ItineraryItem(name: "Banke Bihari Temple", photo: "Banke Bihari", distance: "10 Km"),
    ItineraryItem(name: "radha rani Temple", photo: "RadhaRani temple", distance: "55 Km")
]
