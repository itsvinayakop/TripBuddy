// FamousPlacesView.swift

import SwiftUI

struct FamousPlacesView: View {
    @Environment(\.presentationMode) var presentationMode
    let famousPlaces: [String]
    @State private var selectedPlaces: Set<String> = []

    var body: some View {
        VStack {
            Text("These are the famous places here")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.top, 10)
            
            Text("Select places to know more")
                .font(.subheadline)
                .foregroundColor(.black)
                .padding(.bottom, 30)

            List {
                ForEach(famousPlaces, id: \.self) { place in
                    MultipleSelectionRow(title: place, isSelected: selectedPlaces.contains(place)) {
                        if selectedPlaces.contains(place) {
                            selectedPlaces.remove(place)
                        } else {
                            selectedPlaces.insert(place)
                        }
                    }
                }
            }
            .listStyle(GroupedListStyle())
        }
        .padding()
        .navigationBarTitle("Select Location", displayMode: .inline)
        .navigationBarItems(
            trailing: NavigationLink(destination: ItineraryView(selectedPlaces: selectedPlaces)) {
                Text("Next")
                    .font(.headline)
            }
        )
    }
}
